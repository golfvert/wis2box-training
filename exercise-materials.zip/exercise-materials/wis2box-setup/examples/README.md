# Examples

This directory contains the following examples:

- [`config/`](config): example configurations required to run wis2box (discovery metadata, environment, station list)
- [`scripts/`](scripts): example Python scripts and utilities/helpers
