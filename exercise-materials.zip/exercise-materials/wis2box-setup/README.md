wis2box-training
================

This is a copy of wis2box-1.0b1, in which all images are pulled from docker-hub, to allow us to use the docker-registry-mirror during WIS2-training.

It includes test-data for Malawi to setup wis2box with pre-configured data.